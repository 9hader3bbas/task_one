import 'package:get/get.dart';

abstract class HomeController extends GetxController {}

class HomeControllerImpl extends HomeController {}
