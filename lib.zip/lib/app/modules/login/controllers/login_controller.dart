import 'package:flutter/material.dart';
import 'package:get/get.dart';

abstract class LoginController extends GetxController {
  TextEditingController get emailTEC;

  TextEditingController get passwordTEC;

  FocusNode get emailFN;

  FocusNode get passwordFN;

  RxBool get isPasswordObscured;

  void toggleObscure();
}

class LoginControllerImpl extends LoginController {
  @override
  TextEditingController emailTEC = TextEditingController();

  @override
  TextEditingController passwordTEC = TextEditingController();

  @override
  FocusNode emailFN = FocusNode();

  @override
  FocusNode passwordFN = FocusNode();

  @override
  final RxBool isPasswordObscured = true.obs;
  @override
  void toggleObscure() {
    print("Change Status to ${isPasswordObscured.value}");
    isPasswordObscured.value = !isPasswordObscured.value;
  }
}
