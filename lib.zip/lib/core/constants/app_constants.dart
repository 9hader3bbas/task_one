class AppConstants {
  static const double screenWidth = 393.0;
  static const double screenHeight = 852.0;
}
