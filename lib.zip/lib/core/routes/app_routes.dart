class AppRoutes {
  static const String getStarted = "/get-started";
  static const String loginOrSignup = "/login-or-signup";
  static const String login = "/login";
  static const String home = "/home";
}
