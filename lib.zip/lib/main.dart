import 'package:flutter/material.dart';
import 'package:task_one/app.dart';

void main() {
  runApp(const MainApp());
}
